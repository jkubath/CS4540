#include <signal.h>
#include <stdio.h>
#include <unistd.h>

void handleSignal();
void handleAlarm();
