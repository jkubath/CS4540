void menu(person * people[], int peopleLength, phone * phone[], int phoneLength);
void searchPeople(person * people[], int peopleLength);
void searchPhone(phone * phone[], int phoneLength);