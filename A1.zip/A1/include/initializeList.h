person ** initializePersonList(person ** list, int start, int end);
phone ** initializePhoneList(phone ** list, int start, int end);
