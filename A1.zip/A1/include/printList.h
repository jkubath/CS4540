void printPeople(person ** list);
void printPhoneList(phoneList * head);
void printPhone(phone ** list);
void printPersonList(peopleList * head);

