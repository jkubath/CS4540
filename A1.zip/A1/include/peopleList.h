typedef struct peopleList_s {
	person * person;
	
	struct peopleList_s * next;
} peopleList;
