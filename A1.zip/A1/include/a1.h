#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "person.h"
#include "phone.h"
#include "phoneList.h"
#include "peopleList.h"
#include "file.h"
#include "initializeList.h"
#include "printList.h"
#include "freeThings.h"
#include "interaction.h"

